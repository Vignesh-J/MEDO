/** Automatically generated file. DO NOT MODIFY */
package com.vss.medo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}