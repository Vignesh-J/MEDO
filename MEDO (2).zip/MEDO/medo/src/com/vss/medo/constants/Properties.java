package com.vss.medo.constants;

public class Properties {
	
	public static final String DATABASE_NAME = "PillsReminderDB";
	public static final int MAX_QUANTITY = 60;
	public static final String PREFS_NAME = "settings";
	public static final int SIGNAL_PAUSE = 5;

}
