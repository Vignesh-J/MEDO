package com.vss.medo.constants;

public class MessageTypes {
	
	public static final int EMPTY_NAME = 1;

}
