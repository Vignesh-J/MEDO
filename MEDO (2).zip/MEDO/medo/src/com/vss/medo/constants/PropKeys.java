package com.vss.medo.constants;

public class PropKeys {
	
	public static final String EVENT_ID = "event_id";

}
